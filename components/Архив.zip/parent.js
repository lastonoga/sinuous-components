import create from '~/core/components/create';
import Child from './child';

import { styles, classes, options,  } from '../core/components';
import { observable, computed } from 'sinuous/observable';

export default create(
{
	name: 'Parent',

	state(o)
	{
		return {
			counter: o(1),
		}
	},

	computed(c)
	{
		return {

			mbClass: c(() => {
				return {
					test2: true,
					mb: this._state.counter() % 2 == 0,
				}
			}),

			paddingTop: c(() => {
				return this._state.counter() % 3 == 0 ? '30px' : '100px'
			}),

			colorStyle: c(() => {
				return {
					color: this._state.counter() % 3 == 0 ? 'red' : 'green'
				}
			}),

			text: c(() => {
				return `Counter ${ this._state.counter() }`
			}),

			loopItems: c(() => {

				let items = [];

				let index = this._state.counter();

				// index = Math.abs(5 - index)

				for (var i = 0; i < 1; i++) {
					items.push({
						a: Math.random()
					});
				}

				return items;
			}),
		}
	},

	mounted()
	{
		this.d = setInterval(() => {
			this._state.counter(this._state.counter() + 1)
		}, 1000);
	},

	unmounted()
	{
		clearInterval(this.d);
	},

	/**
	 * Auto generated with single file compile
	 */

	// childComponents()
	// {
	// 	return {
	// 		0: this.createChild(Child, {
	// 			prop1: this._state.counter,
	// 			d: 15,
	// 		}),
	// 	}
	// }

	template()
	{
		return `
			<div :style="[{ paddingTop: paddingTop }, colorStyle]" :class="mbClass" style="color: red;">
			   test
			   {{ text }}
			   text
			   <slot>default text</slot>
			   <i :style="{ paddingTop: paddingTop }" class="a b" disabled>text</i>
			   <child prop1="1" />
			</div>
		`;
	}

});