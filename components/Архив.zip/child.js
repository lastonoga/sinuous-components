import create from '~/core/components/create';
import Child2 from './child2';

export default create(
{

	name: 'child',
	
	props()
	{
		return {
			prop1: {
				type: Number,
				default() {
					return null;
				}
			},

			d: Number,
		}
	},

	data()
	{
		return {
			localProp1: 'test',
		}
	},

	template()
	{
		return `
			<hr/>
			[ Child 1 ]
			<strong style="display: block;">asd</strong>
		`;

		let fc = [
			h('hr'),
			`[ Child 1 ]`,
			h('br'),
			c(() => `Property from parent: ${ ctx._data.prop1() }`),
			h('br'),
			`init property ${ ctx._data.d }`,
			h('hr'),
			'Slots:',
			ctx._slots.default[0],
		];

		for (var i = 0; i < 1; i++) {
			fc.push(h('Child2', {
				props: {
					prop1: ctx._data.localProp1
				}
			}, []));
		}
		// ctx.mounted();
		return h('span', {
			'data-hid': ctx.hid,
			style: { 'background-color': 'rgba(0,0,0,.1)', },
			class: 'd1',
			onclick: () => { alert(ctx._data.d++); }
		}, fc);
	}

});