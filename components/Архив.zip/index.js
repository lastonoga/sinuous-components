import Parent from './parent';
import Child from './child';
import Child2 from './child2';

export {
	Parent,
	Child,
	Child2,
}