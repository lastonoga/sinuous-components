import create from '~/core/components/create';

export default create(
{

	name: 'child2',

	template()
	{
		return `
			<hr/>
			[ Child 1 ]
			<strong style="display: block;">asd</strong>
		`;
		// this.mounted();
		return h('strong', {
			'data-hid': ctx.hid,
			style: {
				color: '#333',
				paddingLeft: '10px',
				paddingRight: '10px',
			},
		}, [
			h('hr'),
			'[ Child 2 ]',
			`passed prop: ${ ctx._data.prop1 }`,
		]);
	}

});